﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    internal class CalculateValues
    {
        public double calAddition(double num1, double num2)
        {
            return num1 + num2;
        }

        public double calSubstraction(double num1, double num2) 
        {
            return num1 - num2;
        }

        public double calMultiplication(double num1, double num2)
        {
            return (num1 * num2);
        }

        public double calDivision(double num1, double num2)
        {
            return (num1 / num2);
        }
    }
}
